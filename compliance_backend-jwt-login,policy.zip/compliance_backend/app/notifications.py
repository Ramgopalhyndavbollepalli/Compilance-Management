from datetime import datetime
from app.models import Notification, db
import traceback
from flask import Blueprint, jsonify

api_bp = Blueprint('api', __name__)

def create_notification(message, user_id="system"):
    """Adds a notification to the database with a user ID or 'system' as the default."""
    try:
        new_notification = Notification(
            message=message,
            user_id=user_id,
            date=datetime.utcnow()
        )
        db.session.add(new_notification)
        db.session.commit()
        print(f"DEBUG: Notification added: {new_notification.to_dict()}")
    except Exception as e:
        db.session.rollback()
        print(f"ERROR: Failed to add notification - {e}")
        print(traceback.format_exc())

@api_bp.route('/notifications', methods=['GET'])
def get_notifications():
    print("DEBUG: Received GET request at /api/notifications")  # Log request for debugging
    try:
        notifications = Notification.query.all()  # Query all notifications from the database
        notifications_data = [notification.to_dict() for notification in notifications]
        print(f"DEBUG: Notifications retrieved: {notifications_data}")  # Log retrieved data
        return jsonify(notifications_data), 200  # Return the notifications as JSON
    except Exception as e:
        print(f"ERROR: Failed to fetch notifications: {e}")  # Log any errors encountered
        print(traceback.format_exc())
        return jsonify({"error": "Failed to fetch notifications"}), 500
