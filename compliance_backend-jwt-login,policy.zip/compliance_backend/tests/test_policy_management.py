import pytest
from datetime import datetime
from app import create_app, db
from app.models import Policy
from flask_jwt_extended import create_access_token

# Set up the Flask application context for testing
@pytest.fixture(scope="module")
def app():
    app = create_app()
    app.config['TESTING'] = True
    with app.app_context():
        db.create_all()  # Create tables
        yield app
        db.session.remove()
        db.drop_all()  # Clean up after tests

@pytest.fixture(scope="module")
def client(app):
    return app.test_client()

@pytest.fixture(scope="module")
def access_token():
    """Provide a valid access token for test cases."""
    with create_app().app_context():
        token = create_access_token(identity=1)  # Assuming user with ID 1
    return token

def test_policy_model(app):
    """Test that a policy object can be created with correct fields."""
    with app.app_context():
        policy = Policy(name="Data Security Policy", description="Policy for data security compliance", category="Security")
        db.session.add(policy)
        db.session.commit()
        assert policy.name == "Data Security Policy"
        assert policy.description == "Policy for data security compliance"
        assert policy.category == "Security"
        assert isinstance(policy.created_at, datetime)

def test_policy_to_dict(app):
    """Test that the to_dict method returns the correct data."""
    with app.app_context():
        policy = Policy(name="Privacy Policy", description="Privacy policy description", category="Privacy")
        db.session.add(policy)
        db.session.commit()
        policy_dict = policy.to_dict()
        assert policy_dict["name"] == "Privacy Policy"
        assert policy_dict["description"] == "Privacy policy description"
        assert policy_dict["category"] == "Privacy"
        assert "created_at" in policy_dict

@pytest.mark.parametrize("name, description, category", [
    ("Updated Policy", "Updated description", "Updated Category"),
])
def test_update_policy(client, access_token, name, description, category):
    """Test updating a policy's details."""
    headers = {"Authorization": f"Bearer {access_token}"}
    
    # Create a policy
    create_response = client.post('/api/policies', headers=headers, json={
        "name": "Initial Policy",
        "description": "Initial description",
        "category": "General"
    })
    policy_id = create_response.get_json()["id"]

    # Update the policy
    update_response = client.put(f'/api/policies/{policy_id}', headers=headers, json={
        "name": name,
        "description": description,
        "category": category
    })
    assert update_response.status_code == 200
    assert update_response.get_json()["message"] == "Policy updated successfully"
    updated_policy = update_response.get_json()["policy"]
    assert updated_policy["name"] == name
    assert updated_policy["description"] == description
    assert updated_policy["category"] == category
