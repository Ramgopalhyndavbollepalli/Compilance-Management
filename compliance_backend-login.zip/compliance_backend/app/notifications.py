from .models import Notification, db
from datetime import datetime
import traceback

def create_notification(message, user="system"):
    """Adds a notification to the database and logs any errors."""
    try:
        new_notification = Notification(message=message, user=user, date=datetime.utcnow())
        db.session.add(new_notification)
        db.session.commit()
        print(f"DEBUG: Notification added - Message: '{message}', User: '{user}'")
    except Exception as e:
        db.session.rollback()
        print(f"ERROR: Failed to add notification: {e}")
        print(traceback.format_exc())
