# tests/test_policy_management.py

import pytest
from app import create_app, db
from app.models import Policy
from flask_jwt_extended import create_access_token
from datetime import datetime

@pytest.fixture
def client():
    app = create_app()
    app.config["TESTING"] = True
    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///:memory:"
    with app.app_context():
        db.create_all()
        yield app.test_client()
        db.session.remove()
        db.drop_all()

@pytest.fixture
def access_token():
    """Create an access token for a test user."""
    app = create_app()
    with app.app_context():
        token = create_access_token(identity=1)
    return token

def test_policy_model():
    """Test that a policy object can be created with correct fields."""
    policy = Policy(name="Data Security Policy", description="Policy for data security compliance", category="Security")
    assert policy.name == "Data Security Policy"
    assert policy.description == "Policy for data security compliance"
    assert policy.category == "Security"
    assert isinstance(policy.created_at, datetime)

def test_policy_to_dict():
    """Test that the to_dict method returns the correct data."""
    policy = Policy(name="Privacy Policy", description="Privacy policy description", category="Privacy")
    policy_dict = policy.to_dict()
    assert policy_dict["name"] == "Privacy Policy"
    assert policy_dict["description"] == "Privacy policy description"
    assert policy_dict["category"] == "Privacy"
    assert "created_at" in policy_dict

def test_create_policy(client, access_token):
    """Test that a new policy can be created."""
    headers = {"Authorization": f"Bearer {access_token}"}
    response = client.post('/api/policies', headers=headers, json={
        "name": "Privacy Policy",
        "description": "Policy on data privacy",
        "category": "Privacy"
    })
    assert response.status_code == 201
    data = response.get_json()
    assert data["name"] == "Privacy Policy"
    assert data["description"] == "Policy on data privacy"
    assert data["category"] == "Privacy"

def test_get_all_policies(client, access_token):
    """Test retrieving all policies."""
    headers = {"Authorization": f"Bearer {access_token}"}
    client.post('/api/policies', headers=headers, json={
        "name": "Policy 1",
        "description": "Description for Policy 1",
        "category": "General"
    })
    client.post('/api/policies', headers=headers, json={
        "name": "Policy 2",
        "description": "Description for Policy 2",
        "category": "Security"
    })
    response = client.get('/api/policies', headers=headers)
    assert response.status_code == 200
    data = response.get_json()
    assert len(data) == 2
    assert data[0]["name"] == "Policy 1"
    assert data[1]["name"] == "Policy 2"

def test_update_policy(client, access_token):
    """Test updating a policy's details."""
    headers = {"Authorization": f"Bearer {access_token}"}
    create_response = client.post('/api/policies', headers=headers, json={
        "name": "Initial Policy",
        "description": "Initial description",
        "category": "General"
    })
    policy_id = create_response.get_json()["id"]

    update_response = client.put(f'/api/policies/{policy_id}', headers=headers, json={
        "name": "Updated Policy",
        "description": "Updated description",
        "category": "Updated Category"
    })
    assert update_response.status_code == 200
    assert update_response.get_json()["message"] == "Policy updated successfully"

    get_response = client.get(f'/api/policies/{policy_id}', headers=headers)
    data = get_response.get_json()
    assert data["name"] == "Updated Policy"
    assert data["description"] == "Updated description"
    assert data["category"] == "Updated Category"

def test_delete_policy(client, access_token):
    """Test deleting a policy."""
    headers = {"Authorization": f"Bearer {access_token}"}
    create_response = client.post('/api/policies', headers=headers, json={
        "name": "Policy to Delete",
        "description": "This policy will be deleted",
        "category": "General"
    })
    policy_id = create_response.get_json()["id"]

    delete_response = client.delete(f'/api/policies/{policy_id}', headers=headers)
    assert delete_response.status_code == 200
    assert delete_response.get_json()["message"] == "Policy deleted successfully"

    get_response = client.get(f'/api/policies/{policy_id}', headers=headers)
    assert get_response.status_code == 404
